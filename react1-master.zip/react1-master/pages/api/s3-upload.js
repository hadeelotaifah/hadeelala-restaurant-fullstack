export { APIRoute as default } from "next-s3-upload";
